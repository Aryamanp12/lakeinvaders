import pygame
import time
import csv
import os
import random
import math
import matplotlib.pyplot as plt

# Prompt for all user inputs upfront
user_id = input("Enter User ID: ")
num_blocks = int(input("Enter the number of blocks: "))

# Initialize Pygame
pygame.init()

# Get desktop size for a windowed fullscreen effect
infoObject = pygame.display.Info()
WIDTH, HEIGHT = infoObject.current_w, infoObject.current_h

# Set up the display in windowed fullscreen (borderless window maximized to screen size)
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.NOFRAME)
pygame.display.set_caption("Lake Invaders")

font = pygame.font.SysFont(None, 30)
clock = pygame.time.Clock()

# Constants
OBJECT_SIZE, CUP_HITBOX_SIZE = 50, 30
MIN_DISTANCE_FROM_POINTS = 200
START_POINT = (WIDTH - 50, HEIGHT - 30)
INITIAL_POINTS = 100
TRIALS_PER_BLOCK = 20

# Load resources
def load_image(file_name, size):
    image = pygame.image.load(file_name)
    return pygame.transform.scale(image, size)

# Loading all the images
cup_image = load_image("ogopogo.png", (OBJECT_SIZE, OBJECT_SIZE))
reset_island_image = load_image("island_reset.png", (OBJECT_SIZE, OBJECT_SIZE))
endpoint_island_image = load_image("island_reset.png", (OBJECT_SIZE, OBJECT_SIZE))
x_mark_image = load_image("x_mark.png", (OBJECT_SIZE, OBJECT_SIZE))
ocean_image = load_image("ocean.jpg", (WIDTH, HEIGHT))
boat_image = load_image("boat.png", (OBJECT_SIZE, OBJECT_SIZE))

# Utility functions
def distance_to_point(point1, point2):
    return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

def calculate_velocity(path, time_elapsed):
    velocities = [distance_to_point(path[i], path[i+1]) for i in range(len(path) - 1)]
    max_velocity = max(velocities) if velocities else 0
    avg_velocity = sum(velocities) / len(velocities) if velocities else 0
    return max_velocity, avg_velocity

def reset_position(rect, reset_rects, cup_positions, points):
    for reset_rect in reset_rects:
        if rect.colliderect(reset_rect):
            rect.center = START_POINT  # Center the boat at START_POINT
            points -= 10
    for cup_position in cup_positions:
        cup_rect = pygame.Rect(cup_position[0], cup_position[1], CUP_HITBOX_SIZE, CUP_HITBOX_SIZE)
        if rect.colliderect(cup_rect):
            rect.center = START_POINT  # Center the boat at START_POINT
            points -= 10
    return points

def create_csv_file(data, folder_name, trial_num, user_id, block_num):
    filename = os.path.join(folder_name, f"trial{trial_num}_results.csv")
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["User ID", "Block Number", "Trial Number", "Reaction Time", "Time Taken", "Max Velocity", "Avg Velocity", "Path", "Final Points"])
        writer.writerow([user_id, block_num, trial_num] + list(data))

def plot_trial(trial_num, path, endpoint, reset_positions, cup_positions, folder_name):
    plt.figure(figsize=(8, 6))
    plt.title(f"Trial {trial_num} Path")
    plt.plot(*zip(*path), marker='o', color='blue', label='Boat Path')
    plt.scatter(*endpoint, color='red', label='Endpoint')
    for pos in reset_positions:
        plt.scatter(*pos, color='green', label='Reset Island' if reset_positions.index(pos) == 0 else "")
    for pos in cup_positions:
        plt.scatter(*pos, color='purple', label='Cup' if cup_positions.index(pos) == 0 else "")
    plt.xlim(0, WIDTH)
    plt.ylim(0, HEIGHT)
    plt.gca().invert_yaxis()
    plt.legend()
    plot_filename = os.path.join(folder_name, f"trial_{trial_num}_path.png")
    plt.savefig(plot_filename)
    plt.close()

def display_continue_screen(block_num):
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    running = False
        screen.fill((0, 0, 0))
        display_text(f"End of Block {block_num}. Press SPACE to continue to the next block.", (WIDTH // 2 - 300, HEIGHT // 2 - 50))
        pygame.display.flip()
        clock.tick(60)

def display_text(text, position):
    text_surface = font.render(text, True, (255, 255, 255))
    screen.blit(text_surface, position)

def generate_positions(num_objects, object_size, min_distance, existing_positions=[]):
    positions = []
    while len(positions) < num_objects:
        x, y = random.randint(object_size, WIDTH - object_size), random.randint(object_size, HEIGHT - object_size)
        rect = pygame.Rect(x, y, object_size, object_size)
        if (distance_to_point(START_POINT, rect.center) >= min_distance and
            all(distance_to_point(pos.center, rect.center) >= object_size for pos in existing_positions)):
            positions.append(rect)
    return positions

def game_trial(num_cups, points, trial_num, block_folder_name):
    boat_rect = pygame.Rect(0, 0, OBJECT_SIZE, OBJECT_SIZE)
    boat_rect.center = START_POINT
    path = [boat_rect.center]
    reset_rects = generate_positions(2, OBJECT_SIZE, MIN_DISTANCE_FROM_POINTS)
    endpoint_rect = generate_positions(1, OBJECT_SIZE, MIN_DISTANCE_FROM_POINTS, reset_rects)[0]
    cup_positions = [(rect.x, rect.y) for rect in generate_positions(num_cups, OBJECT_SIZE, MIN_DISTANCE_FROM_POINTS, reset_rects + [endpoint_rect])]

    dragging = False
    boat_moved = False
    trial_start_time = time.time()
    reaction_time = None
    x_mark_shown = True

    # Draw the white square once at the boat's starting point
    white_square_padding = 5  # Padding for the white square size for visibility
    white_square_start_rect = pygame.Rect(START_POINT[0] - OBJECT_SIZE//2 - white_square_padding, START_POINT[1] - OBJECT_SIZE//2 - white_square_padding, OBJECT_SIZE + 2*white_square_padding, OBJECT_SIZE + 2*white_square_padding)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None, points
            if event.type == pygame.MOUSEBUTTONDOWN and boat_rect.collidepoint(event.pos):
                dragging = True
                boat_moved = True
                if reaction_time is None:
                    reaction_time = time.time() - trial_start_time
            if event.type == pygame.MOUSEBUTTONUP:
                dragging = False
            if dragging and event.type == pygame.MOUSEMOTION:
                boat_rect.move_ip(event.rel)
                path.append(boat_rect.center)
                boat_moved = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    boat_rect.center = START_POINT
                    path = [START_POINT]
                    boat_moved = True

        screen.blit(ocean_image, (0, 0))
        # Always draw the white square at the START_POINT, so it remains stationary
        pygame.draw.rect(screen, (255, 255, 255), white_square_start_rect)
        for reset_rect in reset_rects:
            screen.blit(reset_island_image, reset_rect.topleft)
        screen.blit(endpoint_island_image, endpoint_rect.topleft)
        screen.blit(x_mark_image, endpoint_rect.topleft)
        for cup_position in cup_positions:
            screen.blit(cup_image, cup_position)
        # Ensure the boat is drawn after the white square so it appears on top
        screen.blit(boat_image, boat_rect.topleft)

        points = reset_position(boat_rect, reset_rects, cup_positions, points)
        display_text(f"Points: {points}", (10, 10))
        pygame.display.flip()
        clock.tick(60)

        if boat_rect.colliderect(endpoint_rect):
            trial_end_time = time.time()
            time_taken = trial_end_time - trial_start_time
            max_velocity, avg_velocity = calculate_velocity(path, time_taken)
            points += 20
            reset_positions = [rect.topleft for rect in reset_rects]
            plot_trial(trial_num, path, endpoint_rect.topleft, reset_positions, cup_positions, block_folder_name)
            return (reaction_time, time_taken, max_velocity, avg_velocity, str(path), points), points



def main_game(user_id, num_blocks):
    base_folder_name = user_id
    os.makedirs(base_folder_name, exist_ok=True)
    total_points = 0
    for block in range(1, num_blocks + 1):
        block_folder_name = os.path.join(base_folder_name, f"block_{block}")
        os.makedirs(block_folder_name, exist_ok=True)
        points = INITIAL_POINTS

        num_cups = int(input(f"Enter the number of cup objects for Block {block}: "))

        for trial_num in range(1, TRIALS_PER_BLOCK + 1):
            trial_result = game_trial(num_cups, points, trial_num, block_folder_name)
            if trial_result is None:  # Game was quit
                break
            trial_data, points = trial_result
            create_csv_file(trial_data, block_folder_name, trial_num, user_id, block)
        total_points += points
        print(f"Total points after block {block}: {total_points}")

        if block < num_blocks:
            display_continue_screen(block)

main_game(user_id, num_blocks)

pygame.quit()
